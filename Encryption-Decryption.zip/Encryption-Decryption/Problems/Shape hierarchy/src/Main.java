abstract class Shape {

    abstract double getPerimeter();

    abstract double getArea();
}

class Triangle extends Shape {
    private double a;
    private double b;
    private double c;

    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }


    @Override
    protected double getPerimeter() {
        return a + b + c;
    }

    @Override
    protected double getArea() {
        return Math.sqrt((((a + b + c)/2.0d) * (((a + b + c)/2.0d)-a) * (((a + b + c)/2.0d)-b) * (((a + b + c)/2.0d)-c)));
    }
}

class Rectangle extends Shape {
    protected double a;
    protected double b;

    public Rectangle(double a, double b) {
        this.a = a;
        this.b = b;
    }

    protected double getPerimeter() {
        return (a + b) * 2;
    }

    protected double getArea() {
        return a * b;
    }

}

class Circle extends Shape {
    private double a;

    protected Circle (double a) {
        this.a = a;
    }

    protected double getPerimeter() {
        return (2* Math.PI)*a;
    }

    protected double getArea() {
        return 3.141592653589793 * a * a;
    }

}