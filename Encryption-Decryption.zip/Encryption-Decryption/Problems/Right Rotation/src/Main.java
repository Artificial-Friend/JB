import java.util.Arrays;
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] line = scanner.nextLine().split(" ");

        int count = 0;

        int[] answer = new int[line.length];

        for (int shift = scanner.nextInt(); shift > 0; shift--) {

            if (count >= line.length - 1) {
                count = 0;
            } else {
                ++count;
            }
        }


StringBuilder array = new StringBuilder();

        for (String s : line) {
            if (count >= line.length) {
                count = 0;
            }
//TODO --------------------------------------------------------
       //     array.append(" ").append(answer[count]);

            answer[count] = Integer.parseInt(s);

        //    array.append(" ").append(answer[count]);
//TODO --------------------------------------------------------
            count++;

        }

        for (int s : answer) {
            array.append(" ").append(s);
        }
        System.out.println(array.toString().trim()); //
     //   System.out.println(Arrays.toString(answer)); //TODO array to string
    }
}